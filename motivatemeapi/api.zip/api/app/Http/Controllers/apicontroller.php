<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB;


class apicontroller extends Controller
{
    //
    public function showQuote($quoteCategory){
    	// print_r($quoteCategory);
        $pieces = explode("&", $quoteCategory);
        $maxSize = sizeof($pieces);
        $randomInteger = rand(0,$maxSize-1);       
        // print_r($randomInteger."-----");
        $quotes = DB::table('quotes')->where('type', $pieces[$randomInteger])->get();
        $randomQuoteInteger = rand(0,sizeof($quotes)-1);        
        $quoteArray = (array)$quotes[$randomQuoteInteger];
        // echo "<pre>";

        print_r("{\"quoteText\":\"".$quoteArray['quote']."\"}");
        
    }
    public function userData($chromeId,$username,$createdAt){
    	print_r($chromeId."--".$username."--".$createdAt);
    }
    public function addLikes($quoteId=null,$cromeId=null){
    	print_r("quote id is".$quoteId);
    }
}
