 var quotes = ["\"The Way Get Started Is To Quit Talking And Begin Doing.\" -Walt Disney",
 			   "\"The Pessimist Sees Difficulty In Every Opportunity. The Optimist Sees The Opportunity In Every Difficulty.\" -Winston Churchill",
 			   "\"Don\'t Let Yesterday Take Up Too Much Of Today.\" -Will Rogers",
 			   "\"You Learn More From Failure Than From Success. Don\'t Let It Stop You. Failure Builds Character.\"- Unknown ",
 			   "\"It\'s Not Whether You Get Knocked Down, It\'s Whether You Get Up.\"-Inspirational Quote By Vince Lombardi",
 			   "\"If You Are Working On Something That You Really Care About, You Don\'t Have To Be Pushed. The Vision Pulls You.\"- Steve Jobs",
 			   "\"People Who Are Crazy Enough To Think They Can Change The World, Are The Ones Who Do.\"- Rob Siltanen",
 			   "\"Failure Will Never Overtake Me If My Determination To Succeed Is Strong Enough.\"- Og Mandino",
 			   "\"Entrepreneurs Are Great At Dealing With Uncertainty And Also Very Good At Minimizing Risk. That\'s The Classic Entrepreneur.\"- Mohnish Pabrai",
 			   "\"We May Encounter Many Defeats But We Must Not Be Defeated.\"- Maya Angelou",
 			   "\"Knowing Is Not Enough; We Must Apply. Wishing Is Not Enough; We Must Do.\"- Johann Wolfgang Von Goethe",
 			   "\"Imagine Your Life Is Perfect In Every Respect; What Would It Look Like?\"- Brian Tracy",
 			   "\"We Generate Fears While We Sit. We Overcome Them By Action.\"- Dr. Henry Link",
 			   "\"Whether You Think You Can Or Think You Can\'t, You\'re Right.\"- Henry Ford",
 			   "\"Security Is Mostly A Superstition. Life Is Either A Daring Adventure Or Nothing.\"- Helen Keller",
 			   "\"The Man Who Has Confidence In Himself Gains The Confidence Of Others.\"- Hasidic Proverb",
 			   "\"The Only Limit To Our Realization Of Tomorrow Will Be Our Doubts Of Today.\"- Franklin D. Roosevelt",
 			   "\"Creativity Is Intelligence Having Fun.\"- Albert Einstein",
 			   "\"What You Lack In Talent Can Be Made Up With Desire, Hustle And Giving 110% All The Time.\"- Don Zimmer",
 			   "\"Do What You Can With All You Have, Wherever You Are.\"- Theodore Roosevelt",
 			   "\"Lack of direction, not lack of time, is the problem. We all have twenty-four hour days.\" -Zig Ziglar",
 			   "\"Whenever you want to achieve something, keep your eyes open, concentrate and make sure you know exactly what it is you want. No one can hit their target with their eyes closed.\" -Paulo Coelho",
 			   "\"It is during our darkest moments that we must focus to see the light.\" -Aristotle Onassis",
 			   "\"Concentrate all your thoughts upon the work at hand. The sun\'s rays do not burn until brought to a focus.\" -Alexander Graham Bell",
 			   "\"We are what we repeatedly do. Excellence, then, is not an act but a habit.\" -Will Durant",
 			   "\"The successful warrior is the average man, with laser-like focus.\" -Bruce Lee",
 			   "\"I don\'t care how much power, brilliance or energy you have, if you don\'t harness it and focus it on a specific target, and hold it there you\'re never going to accomplish as much as your ability warrants.\"-Zig Ziglar",
 			   "\"Instead of focusing on that circumstances that you cannot change - focus strongly and powerfully on the circumstances that you can.\" -Joy Page",
 			   "\"It is wise to direct your anger towards problems - not people; to focus your energies on answers - not excuses.\" -William Arthur Ward",
 			   "\"Don\'t dwell on what went wrong. Instead, focus on what to do next. Spend your energies on moving forward toward finding the answer.\" -Denis Waitley",
 			   "\"Most people have no idea of the giant capacity we can immediately command when we focus all of our resources on mastering a single area of our lives.\" -Tony Robbins",
 			   "\"Concentration can be cultivated. One can learn to exercise willpower, discipline one\'s body and train one\'s mind.\" -Anil Ambani",
 			   "Whatever the mind of man can conceive and believe, it can achieve. -Napoleon Hill",
 			   "Two roads diverged in a wood, and I—I took the one less traveled by, And that has made all the difference.  -Robert Frost",
 			   "I attribute my success to this: I never gave or took any excuse. -Florence Nightingale",
 			   "You miss 100% of the shots you don\'t take. -Wayne Gretzky",
 			   "I\'ve missed more than 9000 shots in my career. I\'ve lost almost 300 games. 26 times I\'ve been trusted to take the game winning shot and missed. I\'ve failed over and over and over again in my life. And that is why I succeed. -Michael Jordan",
 			   "The most difficult thing is the decision to act, the rest is merely tenacity. -Amelia Earhart",
 			   "Every strike brings me closer to the next home run. -Babe Ruth",
 			   "Definiteness of purpose is the starting point of all achievement. -W. Clement Stone",
 			   "Life isn\'t about getting and having, it\'s about giving and being. -Kevin Kruse",
 			   "Life is what happens to you while you\'re busy making other plans. -John Lennon",
 			   "We become what we think about. -Earl Nightingale",
 			   "Twenty years from now you will be more disappointed by the things that you didn\'t do than by the ones you did do, so throw off the bowlines, sail away from safe harbor, catch the trade winds in your sails.  Explore, Dream, Discover. -Mark Twain",
 			   "Life is 10% what happens to me and 90% of how I react to it. -Charles Swindoll",
 			   "The most common way people give up their power is by thinking they don\'t have any. -Alice Walker",
 			   "The mind is everything. What you think you become.  -Buddha",
 			   "The best time to plant a tree was 20 years ago. The second best time is now. -Chinese Proverb",
 			   "An unexamined life is not worth living. -Socrates",
 			   "Eighty percent of success is showing up. -Woody Allen",
 			   "Winning isn\'t everything, but wanting to win is. -Vince Lombardi",
 			   "I am not a product of my circumstances. I am a product of my decisions. -Stephen Covey",
 			   "Every child is an artist.  The problem is how to remain an artist once he grows up. -Pablo Picasso",
 			   "Your time is limited, so don\'t waste it living someone else\'s life. -Steve Jobs",
 			   "I\'ve learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel. -Maya Angelou",
 			   "Either you run the day, or the day runs you. -Jim Rohn",
 			   "Whether you think you can or you think you can\'t, you\'re right. -Henry Ford",
 			   "The two most important days in your life are the day you are born and the day you find out why. -Mark Twain",
 			   "The best revenge is massive success. -Frank Sinatra",
 			   "Life shrinks or expands in proportion to one\'s courage. -Anais Nin",
 			   "There is only one way to avoid criticism: do nothing, say nothing, and be nothing. -Aristotle",
 			   "Ask and it will be given to you; search, and you will find; knock and the door will be opened for you. -Jesus",
 			   "The only person you are destined to become is the person you decide to be. -Ralph Waldo Emerson",
 			   "Go confidently in the direction of your dreams.  Live the life you have imagined. -Henry David Thoreau",
 				];
 var colors = [];
 colors[0] = ["#34495e","white"];
 colors[1] = ["#2c3e50","white"];
 colors[2] = ["#9b59b6","white"];
 colors[3] = ["#8e44ad","white"];
 colors[4] = ["#3498db","white"];
 colors[5] = ["#2980b9","white"];
 colors[6] = ["#2ecc71","white"];
 colors[8] = ["#27ae60","white"];
 colors[9] = ["#1abc9c","white"];
 colors[10]= ["#16a085","white"];
 colors[11]= ["#f1c40f","white"];
 colors[12]= ["#f39c12","white"];
 colors[13]= ["#e67e22","white"];
 colors[15]= ["#d35400","white"];
 colors[16]= ["#e74c3c","white"];
 colors[17]= ["#c0392b","white"];
 colors[18]= ["#ecf0f1","black"];
 colors[19]= ["#bdc3c7","black"];
 colors[20]= ["#95a5a6","black"];
 colors[21]= ["#7f8c8d","white"];
 $(document).ready(function() { 
		
 		
	 	$.ajax({
	 		url: "http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-IN",
	 		type: "GET",
	 		dataType:"json",
	 		timeout: 1000, // sets timeout to 1 seconds
	 		success:function(data){
	 			$('.modal').modal();
				$('.collapsible').collapsible();
		 		
		 	    $.ajax({
			 	url: "http://api.forismatic.com/api/1.0/?method=getQuote&key=random&format=json&lang=en",
			 	type:"GET",
			 	dataType:"json",
			 	crossDomain:true,
			 	beforeSend: function() {
		        
		    	},
			 	success: function (quoteData) {
			 		
			 		if(quoteData.quoteText == null || quoteData.quoteText == "" || quoteData.quoteText == " "){
			 			var requiredQuote = "The best revenge is massive success. - Frank Sinatra";
			 		}else if (quoteData.quoteAuthor == null || quoteData.quoteAuthor == "" || quoteData.quoteAuthor == " "){
			 			var requiredQuote = quoteData.quoteText+" -Unknown";
			 		}else{
			 			var requiredQuote = quoteData.quoteText+" -"+quoteData.quoteAuthor;
			 		}

			 		$("#content").text(requiredQuote);
			 		$("#content").css("color","white");
			 		},

			 	complete: function() {
			 		$(".display-loader").hide();
			 		if ($("#content").text() =="null" || $("#content").text() =="" || $("#content").text() ==" " ) {
			 			$("#content").text("The best revenge is massive success. - Frank Sinatra");
			 		}else{
			 			
			 		}
			    },
			 	});
		 		 		
		 		// $("#content").text(quotes[quoteNumber]);

			 	   var myUrl = ["http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-IN",
			 	   				"http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-US",
			 	   				"http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=pt-BR",
			 	   				"http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=de-DE",
			 	   				"http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=ja-JP",
			 	   				"http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=zh-CN"
			 	   			   ];
			 	    var urlPosition = randomIntFromInterval(0,5); 	    
			 	   imageUrl=myUrl[urlPosition];

				   $.ajax({ 
				    url: imageUrl, 	    	    
				    type: "GET",
				    dataType: "json",
				    crossDomain: true,
				    success: function (data) {
				    	
				    	// var dataString = JSON.stringify(data);
				    	// var jsonData = JSON.parse(dataString);
				    	var imageUrl = "http://www.bing.com"+data.images[0].url;	    	
				    	$('#myBody').css('background-image', 'url(' + imageUrl + ')');
				    	
				    }
				});

					 	  
	 		},
	 		error:function(error){
	 			var randomImage = randomIntFromInterval(0,3);
	 			var imageArray = ['img1.jpg','img2.jpg','img3.jpg','img4.jpg'];
	 			$('.floating-margin').hide();
	 			$("#modal1").hide();
	 			$('.preloader-wrapper').hide();
	 			$('#myBody').css('background-image', 'url(' + "/images/"+imageArray[randomImage]+"" + ')');
	 			
	 			var randomQuote = randomIntFromInterval(0,64);
	 			$("#content").text(quotes[randomQuote]);
	 		}
	 	
	 	});

 		$("#content").mouseover(function(){	
			$("#content").css("background-color","rgba(0, 0, 0, 0.5)");
			}
		);
		$("#content").mouseout(function(){
			$("#content").css("background-color","rgba(0, 0, 0, 0)");
		});	
	 	
});


 function randomIntFromInterval(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}

function doesConnectionExist() {
		    var xhr = new XMLHttpRequest();
		    var file = "http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-IN";
		    var randomNum = Math.round(Math.random() * 10000);
		 
		    xhr.open('HEAD', file + "?rand=" + randomNum, true);
		    xhr.send();
		     
		    xhr.addEventListener("readystatechange", processRequest, false);
		 
		    function processRequest(e) {
		      if (xhr.readyState == 4) {
		        if (xhr.status >= 200 && xhr.status < 304) {
		          alert("connection exists!");
		          return 1;
		        } else {
		          alert("connection doesn't exist!");
		          return 0;
		        }
		      }
		    }
		}